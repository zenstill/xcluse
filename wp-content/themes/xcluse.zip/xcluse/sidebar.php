<?php
    global $wpdb, $current_user;?>
<script>
 jQuery(document).ready( function($){
	 $( ".text_search" ).on( "change", function() {
		 cur_search = $(this).val();
		 old_value = $( ".q" ).val();
		 if(old_value){
		con_value = old_value + "," + cur_search;
		 }else{
			 con_value = cur_search;
		 }
		  $(".q").val(con_value);
		   });
          		<?php $attribute_taxonomies = wc_get_attribute_taxonomies();
        foreach ($attribute_taxonomies as $tax) {
            if (taxonomy_exists(wc_attribute_taxonomy_name($tax->attribute_name))) { ?>
		   $(".<?php echo $tax->attribute_name;?>.mtree-active").removeClass('mtree-closed');
		   $(".<?php echo $tax->attribute_name;?>.mtree-active").addClass('mtree-open');
		   $(".<?php echo $tax->attribute_name;?>.filter_block").css("display", "block"); 
		   $(".<?php echo $tax->attribute_name;?>.filter_block").css("height", "250px");
		   <?php } } ?>
		   
		    $( ".delete_brand a" ).on( "click", function() {
				cur_value = $(this).attr('class');
				$('#'+cur_value).prop('checked', false);
				 $("#filter_form").submit();
				 });
	 });
 </script>
 <script>

   $(document).ready(function() {
	   $( "body" ).on( "change", ".text_search", function() {
		   $(".text_search").val('');
		   var datastring = $("#filter_form").serialize();
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajax',  
					formdata:datastring,
					},
					context: this,  
					success: function(data){
						$("#my_jega").html(data);

					}
 	});	
	/* $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajaxclose',  
					formdata:datastring,
					},
					context: this,  
					success: function(data){
						$( ".for_delete_int" ).html(data);

					}
 	});	*/
				
   });
  $( "body" ).on( "click", ".delete_attri a", function() {
	       curr_del_value = $(this).data("value");
		   
		   $("#"+curr_del_value).trigger( "click" );
		   
		   //$("#"+curr_del_value).val('');
		  // $(this).parent('span').remove();
		   var datastring = $("#filter_form").serialize();
		
});	
 /* $( "body" ).on( "click", ".delete_q a", function() {
	      $(".text_search").val('');
	      del_value = $(this).text();
		  $("."+del_value).remove();
		  old_value = $( ".q" ).val();
		  old_arr_value = old_value.split(',');
		  y = jQuery.grep(old_arr_value, function(value) {
			  return value != del_value;
			});
			real_value = y.join(',');
			$( ".q" ).val(real_value);
		   

		   var datastring = $("#filter_form").serialize();
		   
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajax',  
					formdata:datastring,
					},
					context: this,  
					success: function(data){
						$("#my_jega").html(data);

					}
 	});	
	
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajaxclose',  
					formdata:datastring,
					},
					context: this,  
					success: function(data){
						$( ".for_delete_int" ).html(data);
						//$("#my_jega").html(data);
					}
 	});	
		
});	*/
     $( "body" ).on( "click", ".side_checkbox input", function() {
		  $(".text_search").val('');
		   var datastring = $("#filter_form").serialize();
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajax',  
					formdata:datastring,
					},
					context: this,  
					success: function(data){
						$("#my_jega").html(data);

					}
 	});	
	
		    /*$.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajaxclose',  
					formdata:datastring,
					},
					context: this,  
					success: function(data){
						$( ".for_delete_int" ).html(data);
					}
 	});	*/
	
							
   });
   $("#filter_form").submit(function(e){
    return false;
   });
 $( "body" ).on( "click", "#save_search_submit", function() {
		   var datastring = $("#filter_form").serialize();
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'savesearchajax',  
					formdata:datastring,
					},
					context: this,  
					success: function(data){
						$(data).insertBefore('.for_save_search_append'); 
					}
 	});
	});
	
$( "body" ).on( "click", ".list-search .only_for_view", function() {
		   var saved_id = $(this).attr("id");
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'view_savesearchajax',  
					saved_id:saved_id,
					},
					context: this,  
					success: function(data){
						$("#my_jega").html(data);
					}
 	});
	});


/*$( "body" ).on( "click", ".list-search .only_for_view", function() {
		   var saved_id = $(this).attr("id");
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'view_savesearchajax',  
					saved_id:saved_id,
					},
					context: this,  
					success: function(data){
						$("#my_jega").html(data);
					}
 	});
	});	*/
	
	$( "body" ).on( "click", ".saved_search_delete", function() {
		   var saved_id = $(this).data("id");
		   $("#"+saved_id).parent('span').parent('li').remove();
		    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'delete_savesearchajax',  
					saved_id:saved_id,
					},
					context: this,  
					success: function(data){
					}
 	});
	});	
			
   });
</script>
<!---------archive product script-------------->
<script>
	 $(window).load(function() {
		 $(".products").css("display", "show");
	     $(".shop_loading").css("display", "none");
       });
	 $(window).unload(function() {
		$(".products").css("display", "none");
		$(".shop_loading").css("display", "block");
	  });
   $(document).ready(function() {
	  $( ".addtocompare" ).on( "click", function() {
		  product_id = $(this).data( "productid" );
		  request = $(this).data( "request" );
		  //alert(product_id);
	   $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'addtocompare',  
					product_id:product_id,
					request:request
					},
					context: this,  
					success: function(data){
					$(this).ajaxStart(function(){
					    //$(".ajax_loading").css("display", "block");
					});
					$(this).ajaxComplete(function(){
						$(this).html('<i class="added_comp" title="Added to compare"></i>');
					});

					}
 	});				
   });
   });
</script>
<script>

   $(document).ready(function() {
   $( "body" ).on( "click", ".six", function() {

	    $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'change_size',  
					action_id:'six',
					},
					context: this,  
					success: function(data){
				}
 	});				
	
	 $('.for_spcl').removeClass( "col-lg-3" );
	 $('.for_spcl').addClass( "col-lg-2" );
	 $('.layout-picker-four').removeClass( "active" );
	 $('.layout-picker').addClass( "active" );
});
  $( "body" ).on( "click", ".four", function() {
       $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'change_size',  
					action_id:'four',
					},
					context: this,  
					success: function(data){
					}
 	});	
	 $('.for_spcl').removeClass( "col-lg-2" );
	 $('.for_spcl').addClass( "col-lg-3" );
	 $('.layout-picker').removeClass( "active" );
	 $('.layout-picker-four').addClass( "active" );
});
});
</script>
<script>

   $(document).ready(function() {
	   $( "body" ).on( "click", ".addtowishlist", function() {
	 /* $( ".addtowishlist" ).on( "click", function() {*/
		  product_id = $(this).data( "productid" );
		  request = $(this).data( "request" );
		  //alert(product_id);
	   $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'addtowishlist',  
					product_id:product_id,
					request:request
					},
					context: this,  
					success: function(data){
					$(this).ajaxStart(function(){
					    //$(".ajax_loading").css("display", "block");
					});
					$(this).ajaxComplete(function(){
						$(this).toggleClass('addtowishlist addedtowishlist');
						$(this).html('<i class="added_wish_comp" title="Added to wishlist"></i>');
					});

					}
 	});				
   });
   
   	   $( "body" ).on( "change", ".orderby", function() {
	 /* $( ".addtowishlist" ).on( "click", function() {*/
		  orderby = $(this).val();
		  var datastring = $("#filter_form").serialize();
		 // request = $(this).data( "request" );
	   $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'orderbyproducts',  
					formdata:datastring,
					orderby:orderby
					},
					context: this,  
					success: function(data){
					$("#my_jega").html(data);
					}
 	});				
   });
   
   
    $( "body" ).on( "click", ".woocommerce-pagination a", function(e) {
		e.preventDefault();
	 /* $( ".addtowishlist" ).on( "click", function() {*/
		  page_no = $(this).text();
		  var datastring = $("#filter_form").serialize();
		 // request = $(this).data( "request" );
	   $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajax',  
					formdata:datastring,
					page_no:page_no
					},
					context: this,  
					success: function(data){
					$("#my_jega").html(data);
					}
 	});				
   });
   
   
    $( "body" ).on( "click", ".for_next_prev a", function(e) {
		e.preventDefault();
	 /* $( ".addtowishlist" ).on( "click", function() {*/
		  page_no = $(this).data("no");
		  var datastring = $("#filter_form").serialize();
		 // request = $(this).data( "request" );
	   $.ajax({
						  
					type: 'POST',  
					url: '<?php echo admin_url('admin-ajax.php') ?>',  
					data: {  
					action: 'sidebarajax',  
					formdata:datastring,
					page_no:page_no
					},
					context: this,  
					success: function(data){
					$("#my_jega").html(data);
					}
 	});				
   });
   
   
   });
</script>
<script>
   $(document).ready(function() {
$(".j_menu li").hover(function()
{
    //alert( $(this).find(".inner").show());
    $(this).find("ul").show()
});

$(".j_menu li").mouseleave(function()
{
    $(this).find("ul").hide();
});
   });
</script>
<!----------------------->
<aside class="left-grid-border-width_perform col-xs-4 col-md-2 col-sm-2 col-lg-2 widget woocommerce widget_price_filter">
  <!--<aside class="sidebar grid-item large--one-quarter collection-filters widget woocommerce widget_price_filter">-->
  
  <div id="filter-wrapper" class="grid-uniform col-sidebar white-popup">
    <div class="advanced-filters-wrapper filters-left">
      <?php $server_url = strpos($_SERVER['REQUEST_URI'],'/page/');
			 if($server_url){
			       $page_having  = substr($_SERVER['REQUEST_URI'],$server_url);
				   $str_original = str_replace($page_having,'',$_SERVER['REQUEST_URI']);
			 }else{
				   $str_original = $_SERVER['REQUEST_URI'];
			 }?>
      <?php if(is_user_logged_in()){ 
			  $res = $wpdb->get_results("select * from saved_search where user_id=".$current_user->ID);
			  if(!empty($res) && (!empty($_GET['s']) || !empty($_GET['s'])))?>
      <h3>Saved Searches</h3>
      <form name="saved_search" id="saved_search_form" action="" method="post">
        <div class="list-search">
          <ul>
            <?php if(!empty($res)){?>
            <?php foreach($res as $saved_result){?>
            <li><span><a href="javascript:void(0)" class="only_for_view" id="<?php echo $saved_result->id;?>"><?php echo implode(',',unserialize($saved_result->keywords));?></a><a href="javascript:void(0)" class="saved_search_delete" data-id="<?php echo $saved_result->id;?>"><i class="fa fa-times"></i></a></span></li>
            <?php } }?>
            <!--   <li><span>Black, Metal, Chairs<i class="fa fa-times"></i></span></li>
              <li><span>Simple Living, Cocktail Table<i class="fa fa-times"></i></span></li>-->
            <li class="for_save_search_append">
              <a class="search-bar-btn" id="save_search_submit" href="javascript:void(0)">Save this search</a>
            </li>
          </ul>
        </div>
        <?php if($_GET['s']!=""){?>
        <input type="hidden" name="save_keyword[]" value="<?php echo $_GET['s'];?>" />
        <?php } ?>
        <?php if($_GET['q']!=""){?>
                   <?php 	$inner_search = array_filter(explode(":", $_GET['q']));
                  foreach($inner_search as $key_word){ ?>
        <input type="hidden" name="save_keyword[]" value="<?php echo $key_word;?>" />
        <?php } } ?>
                  		<?php  
						$attribute_taxonomies = wc_get_attribute_taxonomies();
        foreach ($attribute_taxonomies as $tax) {
            if (taxonomy_exists(wc_attribute_taxonomy_name($tax->attribute_name))) { ?>
        <?php if($_GET[$tax->attribute_name]!=""){
			foreach($_GET[$tax->attribute_name] as $resul){?>
        <input type="hidden" name="save_keyword[]" value="<?php $term = get_term( $resul, 'pa_'.$tax->attribute_name );echo $term->name;?>" />
        <?php } } } } ?>
        <input type="hidden" name="save_submit" value="1" />
      </form>
      <?php } ?>

      <?php dynamic_sidebar( 'sidebar-widgets' ); ?>
      
<?php //echo get_query_var( 'foo' ); ?>

          <form action="<?php echo $str_original;?>" method="get" class="search-bar-product" role="search" id="filter_form">
      <h3>Search</h3>
      <div class="list-fun">
        <div class="serch-fuction for_my_filter">
        <div class="sub_btn">

            <input type="search" value="" placeholder="Narrow Your Results" aria-label="Search all products" class="text_search" />
            <!--<input type="search" name="q" value="" placeholder="Narrow Your Results" aria-label="Search all products">-->
           
            <input type="hidden" name="s"  value="" class="s" />

             <input type="hidden" name="q" id="q" value="" class="q" />
             
             <input type="hidden" name="main_cat" id="main_cat" value="" class="main_cat_for" />

            <?php if($_POST['sale_id']){ ?>
            <input type="hidden" name="sale" id="sale" value="1" />
            <?php } ?>
           <?php if($_POST['new_id']){ ?>
            <input type="hidden" name="new" id="new" value="1" />
            <?php } ?>
            <button type="submit" class="search-bar--submit icon-fallback-text"> <i class="fa fa-plus"></i> </button>
</div>
<div class="for_delete_int">
          </div>

        </div>
      </div>
<!-----For Sidebar filter------------->

<?php $min_price = min_meta_value();
      $max_price = max_meta_value();
	  //$price_range = 100;
	  //$round_price = $max_price / $price_range;?>
  <ul  class="mtree transit mtree_mainwidth">
              <li class="mtree-node mtree-closed" style="opacity: 1; transform: translateY(0px);"><a href="javascript:void(0)" style="cursor: pointer;">Price</a>
                    <ul class="brand advanced-filters  brand_filter mtree-level-1" style="overflow: hidden; height: 0px; display: none;">
                    <?php for($start=0; $start < $max_price; $start+=1000){?>
                        <li><span class="side_checkbox"> <input type="checkbox" id="46" value="<?php echo $start;?>-<?php echo $start+1000;?>" name="price[]"></span>$<?php echo $start;?> - $ <?php echo $start+1000;?><!--</a>--></li>
						<?php } ?>
                           </ul>
             </li>
       <?php $attribute_taxonomies = wc_get_attribute_taxonomies();?>
       <?php if(!empty($attribute_taxonomies)){?>
       <?php  $taxonomy_terms = array();
        foreach ($attribute_taxonomies as $tax) {
            if (taxonomy_exists(wc_attribute_taxonomy_name($tax->attribute_name)) && $tax->attribute_name != 'availability' && $tax->attribute_name != 'currency' && $tax->attribute_name != 'seller') {?>
            
                  <?php 
	  	  $brand_ids = get_terms( 'pa_'.$tax->attribute_name, 'orderby=id&hide_empty=0&fields=ids' );
		  $curr_term_id = $_GET['cat'];
		  $brand_ids = implode(",", $brand_ids);
if(!isset($_GET['new']) && empty($_GET['new']) && !isset($_GET['sale']) && empty($_GET['sale'])){
			   $curre_posts = $wpdb->get_col("SELECT SQL_CALC_FOUND_ROWS  wp_posts.ID FROM wp_posts
		INNER JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id)  
		INNER JOIN wp_term_relationships AS tt1 ON (wp_posts.ID = tt1.object_id) 
		WHERE 1=1  
		AND (    wp_term_relationships.term_taxonomy_id IN (".$curr_term_id.")    
		AND    tt1.term_taxonomy_id IN (".$brand_ids.") ) 
		AND wp_posts.post_type = 'product' 
		AND (wp_posts.post_status = 'publish' OR wp_posts.post_status = 'private') 
		GROUP BY wp_posts.ID 
		ORDER BY wp_posts.post_date DESC");
}
if(isset($_GET['new']) && !empty($_GET['new'])){
		$curre_posts = $wpdb->get_col("SELECT SQL_CALC_FOUND_ROWS  wp_posts.ID FROM wp_posts  INNER JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id) WHERE 1=1  AND ( 
		  wp_term_relationships.term_taxonomy_id IN (".$brand_ids.")
		) AND wp_posts.post_type = 'product' AND ((wp_posts.post_status = 'publish')) GROUP BY wp_posts.ID ORDER BY wp_posts.post_date DESC LIMIT 0,100");
		//echo "<pre>";print_r($curre_posts);exit;
}
if(isset($_GET['sale']) && !empty($_GET['sale'])){
		$curre_posts = $wpdb->get_col("SELECT SQL_CALC_FOUND_ROWS  wp_posts.ID FROM wp_posts  INNER JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id) INNER JOIN wp_postmeta ON ( wp_posts.ID = wp_postmeta.post_id ) WHERE 1=1  AND ( 
  wp_term_relationships.term_taxonomy_id IN (".$brand_ids.")
) AND ( 
  ( wp_postmeta.meta_key = '_sale_price' AND CAST(wp_postmeta.meta_value AS SIGNED) > '0' )
) AND wp_posts.post_type = 'product' AND ((wp_posts.post_status = 'publish')) GROUP BY wp_posts.ID ORDER BY wp_posts.post_date DESC LIMIT 0,100");
}

			$cur_brand_term = array();
			foreach($curre_posts as $cur_post){
				$term_lists = wp_get_post_terms($cur_post, 'pa_'.$tax->attribute_name, array("fields" => "ids"));
				foreach($term_lists as $term_list){
					if (!in_array($term_list, $cur_brand_term)) {
					$cur_brand_term[] = $term_list;
					}
				}
			}
		if(!empty($cur_brand_term)){
?>

            
            
        <li <?php if($_GET[$tax->attribute_name]){?>class="<?php echo $tax->attribute_name;?> mtree-node mtree-active mtree-open"<?php } ?>><a href="javascript:void(0)"><?php echo $tax->attribute_name;?></a>
          <?php $tax_terms = get_terms( wc_attribute_taxonomy_name($tax->attribute_name), 'orderby=name&hide_empty=0' );
			    //echo "<pre>";print_r($tax_terms);exit;?>
          <ul class="<?php echo $tax->attribute_name;?> advanced-filters <?php if($_GET[$tax->attribute_name]){?> filter_block <?php } ?> brand_filter">
            <?php foreach ($tax_terms as $terms) { 
			  if (in_array($terms->term_id, $cur_brand_term)) {?>
            <li><!--<a href="javascript:void(0)" class="<?php echo $terms->term_id;?>"  <?php if($_GET['pa_'.$tax->attribute_name] == $terms->term_id){?>style="color:#ff0000;"<?php } ?>>--><span class="side_checkbox"> <input type="checkbox" name="<?php echo $tax->attribute_name;?>[]" value="<?php echo $terms->term_id;?>" id="<?php echo $terms->term_id;?>" <?php if(!empty($_GET[$tax->attribute_name])){ if(in_array($terms->term_id,$_GET[$tax->attribute_name])){ ?>checked="checked" <?php } } ?> /></span><?php echo $terms->name;?><!--</a>--></li>
            <?php } ?>
            <?php } ?>
          </ul>
        </li>
        <?php }} } ?>
            <!--<li class="mtree-node mtree-closed" style="opacity: 1; transform: translateY(0px);"><a href="#" style="cursor: pointer;">Rooms</a>
                <ul class="advanced-filters mtree-level-1" style="overflow: hidden; height: 0px; display: none;">
                <li style="opacity: 1; transform: translateY(0px);"><span class="side_checkbox"> <input type="checkbox" name="frerewrwr" value="erer" id="rrytry" /></span>Business</li>
                <li style="opacity: 1; transform: translateY(0px);"><span class="side_checkbox"> <input type="checkbox" name="frerewrwr" value="erer" id="rrytry" /></span>Business</li>
                <li style="opacity: 1; transform: translateY(0px);"><span class="side_checkbox"> <input type="checkbox" name="frerewrwr" value="erer" id="rrytry" /></span>Business</li>
              </ul></li>-->
                    <?php } ?>
      </ul>

<!-----For Sidebar filter------------->
          </form>
      <?php //dynamic_sidebar( 'sidebar-widget-recent-views' ); ?>
    </div>
  </div>
     <?php
	 if(!empty( $_COOKIE['woocommerce_recently_viewed'])){
  $viewed_products = ! empty( $_COOKIE['woocommerce_recently_viewed'] ) ? (array) explode( '|', $_COOKIE['woocommerce_recently_viewed'] ) : array();
		$viewed_products = array_filter( array_map( 'absint', $viewed_products ) );

		if ( empty( $viewed_products ) ) {
			return;
		}

		ob_start();

	    $query_args = array( 'posts_per_page' => 15, 'no_found_rows' => 1, 'post_status' => 'publish', 'post_type' => 'product', 'post__in' => $viewed_products, 'orderby' => 'rand' );

		$query_args['meta_query']   = array();
	    $query_args['meta_query'][] = WC()->query->stock_status_meta_query();
	    $query_args['meta_query']   = array_filter( $query_args['meta_query'] );

		$r = new WP_Query( $query_args );
		if ( $r->have_posts() ) { ?>
  <div  class="grid-uniform">
   <h3 class="related_fun">Recently viewed products</h3>
  <div class="scroll_fuction">

  <ul>
  	<?php while ( $r->have_posts() ) {
				$r->the_post();?>
                <?php global $product; ?>
    <li class="left_recent_product"><a href="<?php echo esc_url( get_permalink( $product->id ) ); ?>" title="<?php echo esc_attr( $product->get_title() ); ?>"><?php echo $product->get_image(); ?> </a></li>
    <?php } ?>
   
  </ul>
  </div>
  </div>
  <?php } } ?>
</aside>
