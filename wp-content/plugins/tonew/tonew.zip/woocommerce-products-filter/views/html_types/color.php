<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
This feature is in the <a href="http://codecanyon.net/item/woocommerce-products-filter-light/11498469?ref=realmag777" target="_blank">premium version only</a><br />
