<div class="berocket_aapf_widget">
    <input type="button" value="<?php echo $title ?>" class="berocket_aapf_widget_update_button" />
</div>
