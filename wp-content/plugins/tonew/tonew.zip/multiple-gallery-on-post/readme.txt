=== Multiple Gallery on Post ===
Contributors: wirka
Tags: gallery, multiple images, multiple metaboxes, multiple galeries
Requires at least: 3.4.0
Tested up to: 3.8
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Very simple gallery plugin embedded on post as metaboxes, be able to add multiple metaboxes in one post with ability to insert multiple images for each.

== Description ==
Very simple gallery plugin embedded on post as metaboxes, be able to add multiple metaboxes in one post with ability to insert multiple images for each.

Features:
1. Unlimited galleries in one post. 
2. Gallery as a metabox for each galleries. 
3. Unlimited images. 
4. Be able to displayed by shortcode or automatically before or after post content.

== Installation ==
1. Upload plugin directory to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Go to settings page on Settings -> Multiple Gallery on Post.
4. Define gallery metaboxes through plugin setting page per content type.
5. Go to edit post or page, it will have new gallery metaboxes(depend on your settings), feel free to add new images.

== Screenshots ==
1. Settings page
2. Add images to gallery through edit post page
3. The galleries preview on post

== Changelog ==
= 0.4 =
* Fix shortable trigger on setting page.
* Fix for multiple shortcode in one post

= 0.3 =
* Fix registering style plugin to wp_head() instead of wp_footer().

= 0.2 =
* Add options to display by shortcode.

= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.3 =
* Fix registering style plugin to wp_head() instead of wp_footer().

= 0.1 =
* Initial release.